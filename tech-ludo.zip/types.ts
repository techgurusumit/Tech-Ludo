
export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export type TokenState = 'home' | 'in_play' | 'finished';

export type GamePhase = 'ROLLING' | 'MOVING';

export interface Token {
  id: number;
  color: PlayerColor;
  position: number; // -1 for home, 0-51 for main path, 101-106 for red home, etc.
  state: TokenState;
}

export interface Player {
  color: PlayerColor;
  tokens: Token[];
}

export interface GameState {
  players: Player[];
  currentPlayerIndex: number;
  diceValue: 1 | 2 | 3 | 4 | 5 | 6 | null;
  phase: GamePhase;
  movableTokens: number[];
}

export interface PlayerConfig {
  color: PlayerColor;
  homeColor: string;
  tokenColor: string;
  startPosition: number;
  homeEntryPosition: number;
  path: number[];
  bg: string;
}
