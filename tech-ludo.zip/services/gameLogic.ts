
import { Player, Token, PlayerColor } from '../types';
import { PLAYER_CONFIG, SAFE_POSITIONS } from '../constants';

export const getMovableTokens = (player: Player, diceValue: number): Token[] => {
  const movable: Token[] = [];
  player.tokens.forEach(token => {
    if (token.state === 'finished') return;
    if (token.state === 'home' && diceValue === 6) {
      movable.push(token);
    }
    if (token.state === 'in_play') {
      const path = PLAYER_CONFIG[player.color].path;
      const currentPathIndex = path.indexOf(token.position);
      if (currentPathIndex + diceValue < path.length) {
        movable.push(token);
      }
    }
  });
  return movable;
};

export const calculateNewPosition = (token: Token, diceValue: number, color: PlayerColor): {newPosition: number, hasFinished: boolean} => {
  if (token.state === 'home' && diceValue === 6) {
    return { newPosition: PLAYER_CONFIG[color].startPosition, hasFinished: false };
  }

  const path = PLAYER_CONFIG[color].path;
  const currentPathIndex = path.indexOf(token.position);
  const newPathIndex = currentPathIndex + diceValue;

  const newPosition = path[newPathIndex];
  const hasFinished = newPathIndex === path.length - 1;

  return { newPosition, hasFinished };
};

export const isMoveValid = (token: Token, movableTokens: number[]): boolean => {
    return movableTokens.includes(token.id);
}

export const handleTokenCollision = (
  currentPlayer: Player,
  newPosition: number,
  allPlayers: Player[]
): { updatedPlayers: Player[], tokenKnocked: boolean } => {
  if (SAFE_POSITIONS.includes(newPosition)) {
    return { updatedPlayers: allPlayers, tokenKnocked: false };
  }
  
  let tokenKnocked = false;
  const updatedPlayers = allPlayers.map(p => {
    // Don't check for collisions with the current player's own tokens
    if (p.color === currentPlayer.color) return p;

    let playerTokensUpdated = false;
    const newTokens = p.tokens.map(token => {
      if (token.position === newPosition) {
        tokenKnocked = true;
        playerTokensUpdated = true;
        return { ...token, position: -1, state: 'home' as 'home' };
      }
      return token;
    });

    if (playerTokensUpdated) {
        return { ...p, tokens: newTokens };
    }
    return p;
  });

  return { updatedPlayers, tokenKnocked };
};

export const hasPlayerWon = (player: Player): boolean => {
  return player.tokens.every(token => token.state === 'finished');
};
