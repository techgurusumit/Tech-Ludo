
import React, { useState, useEffect, useCallback } from 'react';
import { GameState, PlayerColor, Token, GamePhase, Player } from './types';
import { INITIAL_GAME_STATE, PLAYER_CONFIG } from './constants';
import GameBoard from './components/GameBoard';
import Dice from './components/Dice';
import PlayerInfo from './components/PlayerInfo';
import WinnerModal from './components/WinnerModal';
import {
  getMovableTokens,
  calculateNewPosition,
  isMoveValid,
  handleTokenCollision,
  hasPlayerWon,
} from './services/gameLogic';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(INITIAL_GAME_STATE);
  const [winner, setWinner] = useState<PlayerColor | null>(null);
  const [message, setMessage] = useState<string>('');

  const currentPlayer = gameState.players[gameState.currentPlayerIndex];

  const updateMessage = useCallback(() => {
    if (winner) {
      setMessage(`${winner.charAt(0).toUpperCase() + winner.slice(1)} wins the game!`);
    } else {
      const color = currentPlayer.color.charAt(0).toUpperCase() + currentPlayer.color.slice(1);
      const phaseText = gameState.phase === 'ROLLING' ? 'Roll the dice' : 'Move a token';
      setMessage(`${color}'s turn. ${phaseText}.`);
    }
  }, [currentPlayer.color, gameState.phase, winner]);

  useEffect(() => {
    updateMessage();
  }, [updateMessage]);

  const switchPlayer = useCallback(() => {
    setGameState(prev => ({
      ...prev,
      currentPlayerIndex: (prev.currentPlayerIndex + 1) % prev.players.length,
      phase: 'ROLLING',
      diceValue: null,
      movableTokens: [],
    }));
  }, []);

  const handleDiceRoll = () => {
    if (gameState.phase !== 'ROLLING') return;

    const roll = (Math.floor(Math.random() * 6) + 1) as 1 | 2 | 3 | 4 | 5 | 6;
    const movable = getMovableTokens(currentPlayer, roll);

    if (movable.length > 0) {
      setGameState(prev => ({
        ...prev,
        diceValue: roll,
        phase: 'MOVING',
        movableTokens: movable.map(t => t.id),
      }));
    } else {
      setGameState(prev => ({ ...prev, diceValue: roll }));
      setTimeout(() => {
        if (roll !== 6) {
          switchPlayer();
        } else {
          // If a 6 is rolled but no moves are possible, just reset for another roll
           setGameState(prev => ({
            ...prev,
            phase: 'ROLLING',
            diceValue: null,
            movableTokens: [],
          }));
        }
      }, 1000);
    }
  };

  const handleTokenMove = (token: Token) => {
    if (gameState.phase !== 'MOVING' || !gameState.diceValue || !isMoveValid(token, gameState.movableTokens)) return;
    
    const { newPosition, hasFinished } = calculateNewPosition(token, gameState.diceValue, currentPlayer.color);

    setGameState(prev => {
        let newPlayers = [...prev.players];
        let currentPlayerClone = { ...currentPlayer };

        // Update token position
        const tokenIndex = currentPlayerClone.tokens.findIndex(t => t.id === token.id);
        currentPlayerClone.tokens[tokenIndex] = { ...token, position: newPosition, state: hasFinished ? 'finished' : 'in_play' };
        
        const { updatedPlayers, tokenKnocked } = handleTokenCollision(currentPlayerClone, newPosition, newPlayers);
        newPlayers = updatedPlayers;

        const playerWon = hasPlayerWon(currentPlayerClone);
        if (playerWon) {
            setWinner(currentPlayerClone.color);
        }

        newPlayers[prev.currentPlayerIndex] = currentPlayerClone;

        return { ...prev, players: newPlayers };
    });
    
    // Check for extra turn conditions
    const knockedOpponent = handleTokenCollision(currentPlayer, newPosition, gameState.players).tokenKnocked;
    const rolledSix = gameState.diceValue === 6;
    
    if (rolledSix || knockedOpponent || hasFinished) {
         setGameState(prev => ({
            ...prev,
            phase: 'ROLLING',
            diceValue: null,
            movableTokens: [],
        }));
    } else {
        switchPlayer();
    }
  };
  
  const resetGame = () => {
    setGameState(INITIAL_GAME_STATE);
    setWinner(null);
  }

  return (
    <div className={`min-h-screen bg-gray-900 text-white font-sans p-4 flex flex-col items-center justify-center transition-colors duration-500 ${PLAYER_CONFIG[currentPlayer.color].bg}`}>
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-4">
          <h1 className="text-4xl md:text-5xl font-bold tracking-wider">Tech Ludo</h1>
          <p className="text-gray-300 mt-1">only for winners</p>
        </header>

        <main className="flex flex-col lg:flex-row items-center justify-center gap-8">
          <div className="flex-shrink-0">
             <GameBoard gameState={gameState} onTokenMove={handleTokenMove} />
          </div>

          <div className="w-full lg:w-64 flex flex-col items-center gap-6">
            <div className="bg-black bg-opacity-40 p-4 rounded-xl shadow-lg w-full text-center">
              <h2 className="text-2xl font-semibold mb-2">Game Status</h2>
              <p className="text-lg min-h-[56px] flex items-center justify-center">{message}</p>
            </div>
            
            <Dice
              value={gameState.diceValue}
              onRoll={handleDiceRoll}
              rolling={gameState.phase === 'ROLLING'}
              playerColor={currentPlayer.color}
            />

            <div className="grid grid-cols-2 gap-4 w-full">
              {gameState.players.map(p => (
                <PlayerInfo key={p.color} player={p} isCurrent={p.color === currentPlayer.color} />
              ))}
            </div>
          </div>
        </main>
      </div>
      {winner && <WinnerModal winner={winner} onReset={resetGame} />}
    </div>
  );
};

export default App;
