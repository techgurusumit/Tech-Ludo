import { GameState, PlayerColor, PlayerConfig, Token } from './types';

export const PLAYER_COLORS: PlayerColor[] = ['red', 'green', 'blue', 'yellow'];

const MAIN_PATH_LENGTH = 52;
const HOME_PATH_LENGTH = 6;

const generatePlayerPath = (startPos: number, homeEntry: number, color: PlayerColor): number[] => {
    const path: number[] = [];
    // Main path
    for (let i = 0; i < MAIN_PATH_LENGTH; i++) {
        path.push((startPos + i) % MAIN_PATH_LENGTH);
        if (path[path.length - 1] === homeEntry) break;
    }
    // Home path
    const homeBase = (['red', 'green', 'blue', 'yellow'].indexOf(color) + 1) * 100;
    for (let i = 1; i <= HOME_PATH_LENGTH; i++) {
        path.push(homeBase + i);
    }
    return path;
};


export const PLAYER_CONFIG: Record<PlayerColor, PlayerConfig> = {
  red: {
    color: 'red',
    homeColor: 'bg-red-600',
    tokenColor: 'bg-red-500',
    startPosition: 0,
    homeEntryPosition: 51,
    path: [], // Will be generated below
    bg: 'bg-gradient-to-br from-red-800 via-gray-900 to-gray-900'
  },
  green: {
    color: 'green',
    homeColor: 'bg-green-600',
    tokenColor: 'bg-green-500',
    startPosition: 13,
    homeEntryPosition: 12,
    path: [],
    bg: 'bg-gradient-to-br from-green-800 via-gray-900 to-gray-900'
  },
  blue: {
    color: 'blue',
    homeColor: 'bg-blue-600',
    tokenColor: 'bg-blue-500',
    startPosition: 39,
    homeEntryPosition: 38,
    path: [],
    bg: 'bg-gradient-to-br from-blue-800 via-gray-900 to-gray-900'
  },
  yellow: {
    color: 'yellow',
    homeColor: 'bg-yellow-500',
    tokenColor: 'bg-yellow-400',
    startPosition: 26,
    homeEntryPosition: 25,
    path: [],
    bg: 'bg-gradient-to-br from-yellow-800 via-gray-900 to-gray-900'
  }
};

// Generate paths after config is defined
PLAYER_CONFIG.red.path = generatePlayerPath(PLAYER_CONFIG.red.startPosition, PLAYER_CONFIG.red.homeEntryPosition, 'red');
PLAYER_CONFIG.green.path = generatePlayerPath(PLAYER_CONFIG.green.startPosition, PLAYER_CONFIG.green.homeEntryPosition, 'green');
PLAYER_CONFIG.blue.path = generatePlayerPath(PLAYER_CONFIG.blue.startPosition, PLAYER_CONFIG.blue.homeEntryPosition, 'blue');
PLAYER_CONFIG.yellow.path = generatePlayerPath(PLAYER_CONFIG.yellow.startPosition, PLAYER_CONFIG.yellow.homeEntryPosition, 'yellow');


export const SAFE_POSITIONS = [0, 8, 13, 21, 26, 34, 39, 47];


export const INITIAL_GAME_STATE: GameState = {
  players: PLAYER_COLORS.map((color, playerIndex) => ({
    color,
    tokens: Array.from({ length: 4 }, (_, i) => ({
      id: playerIndex * 4 + i,
      color,
      position: -1,
      state: 'home',
    })),
  })),
  currentPlayerIndex: 0,
  diceValue: null,
  phase: 'ROLLING',
  movableTokens: [],
};

export const POSITION_COORDINATES: { [key: number]: { row: number; col: number } } = {
  // Main path (clockwise)
  0: { row: 7, col: 2 }, 1: { row: 7, col: 3 }, 2: { row: 7, col: 4 }, 3: { row: 7, col: 5 }, 4: { row: 7, col: 6 },
  5: { row: 6, col: 7 }, 6: { row: 5, col: 7 }, 7: { row: 4, col: 7 }, 8: { row: 3, col: 7 }, 9: { row: 2, col: 7 }, 10: { row: 1, col: 7 },
  11: { row: 1, col: 8 }, 12: { row: 1, col: 9 },
  13: { row: 2, col: 9 }, 14: { row: 3, col: 9 }, 15: { row: 4, col: 9 }, 16: { row: 5, col: 9 }, 17: { row: 6, col: 9 },
  18: { row: 7, col: 10 }, 19: { row: 7, col: 11 }, 20: { row: 7, col: 12 }, 21: { row: 7, col: 13 }, 22: { row: 7, col: 14 }, 23: { row: 7, col: 15 },
  24: { row: 8, col: 15 }, 25: { row: 9, col: 15 },
  26: { row: 9, col: 14 }, 27: { row: 9, col: 13 }, 28: { row: 9, col: 12 }, 29: { row: 9, col: 11 }, 30: { row: 9, col: 10 },
  31: { row: 10, col: 9 }, 32: { row: 11, col: 9 }, 33: { row: 12, col: 9 }, 34: { row: 13, col: 9 }, 35: { row: 14, col: 9 }, 36: { row: 15, col: 9 },
  37: { row: 15, col: 8 }, 38: { row: 15, col: 7 },
  39: { row: 14, col: 7 }, 40: { row: 13, col: 7 }, 41: { row: 12, col: 7 }, 42: { row: 11, col: 7 }, 43: { row: 10, col: 7 },
  44: { row: 9, col: 6 }, 45: { row: 9, col: 5 }, 46: { row: 9, col: 4 }, 47: { row: 9, col: 3 }, 48: { row: 9, col: 2 }, 49: { row: 9, col: 1 },
  50: { row: 8, col: 1 }, 51: { row: 7, col: 1 },

  // Home paths
  // Red (101-106)
  101: { row: 8, col: 2 }, 102: { row: 8, col: 3 }, 103: { row: 8, col: 4 }, 104: { row: 8, col: 5 }, 105: { row: 8, col: 6 }, 106: { row: 8, col: 7 },
  // Green (201-206)
  201: { row: 2, col: 8 }, 202: { row: 3, col: 8 }, 203: { row: 4, col: 8 }, 204: { row: 5, col: 8 }, 205: { row: 6, col: 8 }, 206: { row: 7, col: 8 },
  // Blue (401-406)
  401: { row: 14, col: 8 }, 402: { row: 13, col: 8 }, 403: { row: 12, col: 8 }, 404: { row: 11, col: 8 }, 405: { row: 10, col: 8 }, 406: { row: 9, col: 8 },
  // Yellow (301-306)
  301: { row: 8, col: 14 }, 302: { row: 8, col: 13 }, 303: { row: 8, col: 12 }, 304: { row: 8, col: 11 }, 305: { row: 8, col: 10 }, 306: { row: 8, col: 9 },
};
