import React from 'react';
import { GameState, Token, PlayerColor } from '../types';
// FIX: Import PLAYER_COLORS constant to resolve reference errors.
import { PLAYER_CONFIG, SAFE_POSITIONS, POSITION_COORDINATES, PLAYER_COLORS } from '../constants';

const TokenComponent: React.FC<{
  token: Token;
  isMovable: boolean;
  onClick: () => void;
}> = ({ token, isMovable, onClick }) => {
  const config = PLAYER_CONFIG[token.color];
  const animationClass = isMovable ? 'animate-pulse cursor-pointer hover:scale-110' : 'cursor-default';
  const baseClasses = 'w-full h-full rounded-full border-2 border-white/50 shadow-lg flex items-center justify-center transition-transform duration-200';
  return (
    <div
      className={`${baseClasses} ${config.tokenColor} ${animationClass} z-10`}
      onClick={isMovable ? onClick : undefined}
      aria-label={`${token.color} token ${isMovable ? 'movable' : ''}`}
      role="button"
    >
        <div className="w-[40%] h-[40%] bg-white/50 rounded-full"></div>
    </div>
  );
};

const HomeYard: React.FC<{
    player: GameState['players'][0];
    onTokenClick: (token: Token) => void;
    movableTokens: number[];
}> = ({ player, onTokenClick, movableTokens }) => {
    const homeTokens = player.tokens.filter(t => t.state === 'home');
    return (
        <div className="w-full h-full grid grid-cols-2 grid-rows-2 p-1 gap-1 place-items-center">
            {Array(4).fill(0).map((_, i) => (
                <div key={i} className="w-full h-full rounded-full bg-black/20 flex items-center justify-center p-1">
                    {homeTokens[i] && <TokenComponent token={homeTokens[i]} isMovable={movableTokens.includes(homeTokens[i].id)} onClick={() => onTokenClick(homeTokens[i])} />}
                </div>
            ))}
        </div>
    );
};

const GameBoard: React.FC<{ gameState: GameState; onTokenMove: (token: Token) => void; }> = ({ gameState, onTokenMove }) => {
  const allTokens = gameState.players.flatMap(p => p.tokens);
  
  const tokensByPosition: { [key: number]: Token[] } = allTokens
    .filter(t => t.state !== 'home')
    .reduce((acc, token) => {
      if (!acc[token.position]) {
        acc[token.position] = [];
      }
      acc[token.position].push(token);
      return acc;
    }, {} as { [key: number]: Token[] });

  return (
    <div className="bg-black/30 p-2 rounded-lg shadow-2xl">
      <div 
        className="grid relative w-[24rem] h-[24rem] md:w-[32rem] md:h-[32rem]"
        style={{
            gridTemplateColumns: 'repeat(15, minmax(0, 1fr))',
            gridTemplateRows: 'repeat(15, minmax(0, 1fr))',
        }}
      >
        {/* Base Colors */}
        <div className={PLAYER_CONFIG.red.homeColor} style={{ gridArea: '1 / 1 / 7 / 7' }} />
        <div className={PLAYER_CONFIG.green.homeColor} style={{ gridArea: '1 / 10 / 7 / 16' }} />
        <div className={PLAYER_CONFIG.blue.homeColor} style={{ gridArea: '10 / 1 / 16 / 7' }} />
        <div className={PLAYER_CONFIG.yellow.homeColor} style={{ gridArea: '10 / 10 / 16 / 16' }} />
        
        {/* Home Yards */}
        <div style={{ gridArea: '2 / 2 / 6 / 6' }}><HomeYard player={gameState.players[0]} onTokenClick={onTokenMove} movableTokens={gameState.movableTokens} /></div>
        <div style={{ gridArea: '2 / 11 / 6 / 15' }}><HomeYard player={gameState.players[1]} onTokenClick={onTokenMove} movableTokens={gameState.movableTokens} /></div>
        <div style={{ gridArea: '11 / 2 / 15 / 6' }}><HomeYard player={gameState.players[2]} onTokenClick={onTokenMove} movableTokens={gameState.movableTokens} /></div>
        <div style={{ gridArea: '11 / 11 / 15 / 15' }}><HomeYard player={gameState.players[3]} onTokenClick={onTokenMove} movableTokens={gameState.movableTokens} /></div>
        
        {/* Path Cells */}
        {Object.entries(POSITION_COORDINATES).map(([pos, { row, col }]) => {
          const position = parseInt(pos, 10);
          const isSafe = SAFE_POSITIONS.includes(position);
          let bgColor = 'bg-gray-200';
          let textColor = 'text-gray-800';

          const playerColor = PLAYER_COLORS.find(c => PLAYER_CONFIG[c].path.includes(position));
          if (position > 100 && playerColor) {
              bgColor = PLAYER_CONFIG[playerColor].homeColor;
          }

          if (position === 0 || position === 13 || position === 26 || position === 39) {
             const startColor = allTokens.find(t=> t.position === position)?.color || PLAYER_COLORS.find(c=>PLAYER_CONFIG[c].startPosition === position);
             if (startColor) {
                 bgColor = PLAYER_CONFIG[startColor].homeColor;
             }
          }
          
          return (
            <div key={pos} style={{ gridArea: `${row} / ${col}` }} className={`border border-gray-400/50 flex items-center justify-center relative ${bgColor}`}>
              {isSafe && <div className="absolute text-lg">★</div>}
              <div className="absolute w-full h-full flex items-center justify-center p-0.5">
                {tokensByPosition[position]?.map(token => (
                    <TokenComponent 
                        key={token.id} 
                        token={token} 
                        isMovable={gameState.movableTokens.includes(token.id)}
                        onClick={() => onTokenMove(token)} 
                    />
                ))}
              </div>
            </div>
          );
        })}

        {/* Center Triangles */}
        <div style={{ gridArea: '7 / 7 / 10 / 10', position: 'relative' }}>
          <div className="w-full h-full absolute" style={{backgroundColor: PLAYER_CONFIG.red.homeColor, clipPath: 'polygon(0% 0%, 100% 50%, 0% 100%)'}}></div>
          <div className="w-full h-full absolute" style={{backgroundColor: PLAYER_CONFIG.green.homeColor, clipPath: 'polygon(0% 0%, 100% 0%, 50% 100%)'}}></div>
          <div className="w-full h-full absolute" style={{backgroundColor: PLAYER_CONFIG.yellow.homeColor, clipPath: 'polygon(100% 0%, 0% 50%, 100% 100%)'}}></div>
          <div className="w-full h-full absolute" style={{backgroundColor: PLAYER_CONFIG.blue.homeColor, clipPath: 'polygon(50% 0%, 100% 100%, 0% 100%)'}}></div>
        </div>

        {/* Direction Arrows */}
        <div style={{gridArea: '8 / 1'}} className="flex items-center justify-center text-red-100 text-2xl font-bold">→</div>
        <div style={{gridArea: '1 / 8'}} className="flex items-center justify-center text-green-100 text-2xl font-bold">↓</div>
        <div style={{gridArea: '8 / 15'}} className="flex items-center justify-center text-yellow-100 text-2xl font-bold">←</div>
        <div style={{gridArea: '15 / 8'}} className="flex items-center justify-center text-blue-100 text-2xl font-bold">↑</div>
      </div>
    </div>
  );
};

export default GameBoard;