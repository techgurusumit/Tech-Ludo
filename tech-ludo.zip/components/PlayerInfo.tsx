
import React from 'react';
import { Player } from '../types';
import { PLAYER_CONFIG } from '../constants';

interface PlayerInfoProps {
  player: Player;
  isCurrent: boolean;
}

const PlayerInfo: React.FC<PlayerInfoProps> = ({ player, isCurrent }) => {
  const config = PLAYER_CONFIG[player.color];
  const finishedTokens = player.tokens.filter(t => t.state === 'finished').length;
  
  return (
    <div className={`p-2 rounded-lg transition-all duration-300 ${isCurrent ? 'bg-white/30 scale-105' : 'bg-black/30'}`}>
      <div className="flex items-center gap-2">
        <div className={`w-6 h-6 rounded-full ${config.tokenColor} border-2 ${isCurrent ? 'border-white' : 'border-transparent'}`}></div>
        <span className="font-bold capitalize">{player.color}</span>
      </div>
      <div className="mt-2 text-sm text-gray-300">
        Finished: {finishedTokens} / 4
      </div>
    </div>
  );
};

export default PlayerInfo;
