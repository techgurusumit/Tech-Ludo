
import React, { useState, useEffect } from 'react';
import { PlayerColor } from '../types';
import { PLAYER_CONFIG } from '../constants';

interface DiceProps {
  value: number | null;
  onRoll: () => void;
  rolling: boolean;
  playerColor: PlayerColor;
}

const Dice: React.FC<DiceProps> = ({ value, onRoll, rolling, playerColor }) => {
  const [displayValue, setDisplayValue] = useState<number | null>(value);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
  const config = PLAYER_CONFIG[playerColor];

  useEffect(() => {
    if (value !== null) {
      setIsAnimating(true);
      // Simulate a quick roll animation
      const rollInterval = setInterval(() => {
        setDisplayValue(Math.floor(Math.random() * 6) + 1);
      }, 50);

      setTimeout(() => {
        clearInterval(rollInterval);
        setIsAnimating(false);
        setDisplayValue(value);
      }, 500);
    } else {
        setDisplayValue(null);
    }
  }, [value]);
  
  const dotPositions: { [key: number]: string[] } = {
    1: ['center'],
    2: ['top-left', 'bottom-right'],
    3: ['top-left', 'center', 'bottom-right'],
    4: ['top-left', 'top-right', 'bottom-left', 'bottom-right'],
    5: ['top-left', 'top-right', 'center', 'bottom-left', 'bottom-right'],
    6: ['top-left', 'top-right', 'mid-left', 'mid-right', 'bottom-left', 'bottom-right'],
  };

  const renderDots = (val: number) => {
    return dotPositions[val].map((pos) => {
        let classes = 'w-3 h-3 md:w-4 md:h-4 bg-white rounded-full absolute';
        if (pos === 'center') classes += ' top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2';
        if (pos === 'top-left') classes += ' top-2 left-2 md:top-3 md:left-3';
        if (pos === 'top-right') classes += ' top-2 right-2 md:top-3 md:right-3';
        if (pos === 'bottom-left') classes += ' bottom-2 left-2 md:bottom-3 md:left-3';
        if (pos === 'bottom-right') classes += ' bottom-2 right-2 md:bottom-3 md:right-3';
        if (pos === 'mid-left') classes += ' top-1/2 left-2 md:left-3 -translate-y-1/2';
        if (pos === 'mid-right') classes += ' top-1/2 right-2 md:right-3 -translate-y-1/2';
        return <div key={pos} className={classes}></div>;
    });
  };

  return (
    <button
      onClick={onRoll}
      disabled={!rolling || isAnimating}
      className={`w-24 h-24 md:w-32 md:h-32 rounded-2xl flex items-center justify-center transition-all duration-300 focus:outline-none focus:ring-4
        ${rolling ? `${config.tokenColor} hover:${config.homeColor} shadow-lg cursor-pointer focus:ring-white/50` : 'bg-gray-700 shadow-inner cursor-not-allowed'}
        ${isAnimating ? 'animate-spin' : ''}`}
    >
      <div className="w-20 h-20 md:w-28 md:h-28 bg-black/30 rounded-lg relative">
        {displayValue && renderDots(displayValue)}
        {!displayValue && rolling && <span className="text-white animate-pulse">Roll!</span>}
      </div>
    </button>
  );
};

export default Dice;
