
import React from 'react';
import { PlayerColor } from '../types';
import { PLAYER_CONFIG } from '../constants';

interface WinnerModalProps {
  winner: PlayerColor;
  onReset: () => void;
}

const WinnerModal: React.FC<WinnerModalProps> = ({ winner, onReset }) => {
  const config = PLAYER_CONFIG[winner];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className={`p-8 rounded-2xl shadow-lg text-center border-4 ${config.homeColor} bg-gray-800 transform transition-all animate-fade-in-up`}>
        <h2 className="text-4xl font-bold mb-2">Congratulations!</h2>
        <p className={`text-3xl font-semibold capitalize mb-6 ${config.tokenColor.replace('bg-','text-')}`}>
          {winner} Wins!
        </p>
        <button
          onClick={onReset}
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-lg text-xl transition-transform duration-200 hover:scale-105"
        >
          Play Again
        </button>
      </div>
       <style>{`
        @keyframes fade-in-up {
          0% {
            opacity: 0;
            transform: translateY(20px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default WinnerModal;
